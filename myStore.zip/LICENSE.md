﻿Copyright © 2022, myStore, Inc.

This is the first version from MyStore app.
Using this app under this license is permitted for testing and educational use only and not permitted for commercial use.
In case you want to use this app for any commercial purpose you have to contact to MyStore Inc.
